public class TimeRecord {
    private String date;
    private String timeIn;
    private String timeOut;
    private double totalHoursWorked;

    // CONSTRUCTOR
    public TimeRecord(String date) {
        this.date = date;
        this.totalHoursWorked = 0.0;
    }

    // GETTER: Allows Payroll to access hours worked.
    public double getTotalHoursWorked() {
        return this.totalHoursWorked;
    }

    // BEHAVIORS
    public void logTimeIn(String time) {
        this.timeIn = time;
        System.out.println("Time In  (" + date + "): " + time);
    }

    public void logTimeOut(String time) {
        this.timeOut = time;
        System.out.println("Time Out (" + date + "): " + time);
    }

    public void calculateDailyHours(double hours) {
        // Bulletproof check: You cannot work negative hours.
        if (hours >= 0) {
            this.totalHoursWorked = hours;
        } else {
            System.out.println("Warning: Invalid hours entered. Setting to 0.");
            this.totalHoursWorked = 0.0;
        }
    }
}